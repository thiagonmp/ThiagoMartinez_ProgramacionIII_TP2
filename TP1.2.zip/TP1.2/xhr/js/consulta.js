function irAModificar(id) { location.href = "alta.html?id=" + encodeURIComponent(id); }

function mostrarEnTabla(autos) { mostrarAutos($("lista"), autos, irAModificar, borrar); }

function cargarTodos() {
  $("estado").textContent = "Cargando automóviles… (la primera vez puede tardar hasta un minuto)";
  obtenerAutos(function (autos) {
    console.log(autos);
    mostrarEnTabla(autos);
    $("estado").textContent = autos.length + " automóviles.";
  }, function (texto) {
    $("estado").textContent = "No se pudo cargar la lista.";
    mostrarError(texto);
  });
}

function borrar(id) {
  if (!confirm("¿Seguro que querés eliminar el automóvil " + id + "?")) return;
  eliminarAuto(id, function () {
    mostrarMensaje("✓ Automóvil eliminado correctamente.", "ok");
    cargarTodos(); // la tabla refleja la eliminación
  }, mostrarError);
}

$("form-buscar").addEventListener("submit", function (ev) {
  ev.preventDefault();
  const id = idValido($("id-buscar").value);
  if (id === null) return mostrarError(MSG_ID_INVALIDO);
  limpiarMensaje();
  obtenerAuto(id, function (auto) {
    mostrarEnTabla([auto]); // reemplaza la tabla anterior
    $("estado").textContent = "Resultado de la búsqueda por ID.";
    mostrarMensaje("✓ Automóvil encontrado.", "ok");
  }, function (texto) {
    mostrarEnTabla([]);
    $("estado").textContent = "Sin resultados.";
    mostrarError(texto);
  });
});

$("btn-todos").addEventListener("click", function () { limpiarMensaje(); cargarTodos(); });

cargarTodos();
