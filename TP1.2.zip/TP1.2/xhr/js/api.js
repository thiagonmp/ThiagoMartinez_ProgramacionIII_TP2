// Acceso a la API usando EXCLUSIVAMENTE XMLHttpRequest (sin fetch).
const API = "https://api-autos-tgwd.onrender.com/autos";

function solicitar(metodo, ruta, cuerpo, exito, fallo) {
  const xhr = new XMLHttpRequest();          // 1. crear el objeto
  xhr.open(metodo, API + ruta);              // 2. configurar la solicitud
  xhr.timeout = 90000;                       //    la API gratuita puede tardar en despertar
  if (cuerpo !== undefined) xhr.setRequestHeader("Content-Type", "application/json");

  xhr.onreadystatechange = function () {     // 3. detectar cuándo finaliza
    if (xhr.readyState !== XMLHttpRequest.DONE) return;
    if (xhr.status === 0) return fallo(MSG_CONEXION); // sin respuesta: conexión caída o timeout

    let datos = null;
    try { datos = JSON.parse(xhr.responseText); } catch (e) { /* respuesta sin JSON */ }

    if (xhr.status >= 200 && xhr.status < 300) exito(datos);   // 4. verificar código HTTP
    else fallo(mensajeHttp(xhr.status, datos));
  };

  xhr.send(cuerpo !== undefined ? JSON.stringify(cuerpo) : null); // 5. enviar
}

function obtenerAutos(exito, fallo) {
  solicitar("GET", "", undefined, (d) => exito(listaDeAutos(d)), fallo);
}
function obtenerAuto(id, exito, fallo) {
  solicitar("GET", "/" + id, undefined, (d) => {
    const auto = autoDe(d);
    if (auto) exito(auto); else fallo(MSG_NO_EXISTE);
  }, fallo);
}
function agregarAuto(auto, exito, fallo) { solicitar("POST", "", auto, exito, fallo); }
function modificarAuto(id, auto, exito, fallo) { solicitar("PUT", "/" + id, auto, exito, fallo); }
function eliminarAuto(id, exito, fallo) { solicitar("DELETE", "/" + id, undefined, exito, fallo); }
