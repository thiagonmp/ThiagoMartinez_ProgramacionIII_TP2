# TP2 · Cliente web para la API de autos (XMLHttpRequest vs fetch)

Dos versiones **funcionalmente equivalentes** del mismo cliente web. La API REST (`https://api-autos-tgwd.onrender.com/autos`) no cambia: lo único que cambia es cómo JavaScript hace las solicitudes HTTP.

## Estructura

```
tp2/
├── xhr/      Versión A: solo XMLHttpRequest (callbacks), sin fetch()
│   ├── index.html · consulta.html · alta.html
│   ├── css/estilos.css
│   └── js/  ui.js · api.js · consulta.js · alta.js
├── fetch/    Versión B: solo fetch() con async/await, sin XMLHttpRequest
│   └── (mismos archivos)
└── README.md
```

- `ui.js` es **idéntico** en las dos versiones (tabla dinámica, mensajes, validaciones).
- `api.js` concentra todo el acceso a la API: `obtenerAutos()`, `obtenerAuto(id)`, `agregarAuto()`, `modificarAuto(id)`, `eliminarAuto(id)`.
- `consulta.js` y `alta.js` son la lógica de cada página.

## Funcionalidad (igual en ambas)

- **Consultar:** tabla dinámica con ID, Marca, Precio, Color (cuadro de color + hexadecimal) y Acción. Búsqueda por ID sin recargar la página (reemplaza la tabla) y botón "Ver todos".
- **Modificar:** el botón de cada fila redirige a `alta.html?id=25`. La página recupera el ID desde la URL, trae el auto con `GET /autos/:id`, muestra sus datos (el ID no se puede editar) y guarda con `PUT /autos/:id`.
- **Eliminar:** el botón de cada fila pide confirmación, hace `DELETE /autos/:id` y recarga la tabla.
- **Alta:** `POST /autos` con cuerpo JSON. El ID es opcional (vacío = lo genera la API). Los controles se limpian solo si la operación fue exitosa.
- **Mensajes:** se muestran dentro de la página y en la consola; en alta y modificación también con `alert()`.

### Manejo de errores

| Situación | Mensaje |
|---|---|
| Automóvil inexistente (404) | ✗ No existe un automóvil con ese ID. |
| ID duplicado (409 o mensaje "ya existe") | ✗ Ya existe un automóvil con ese ID. |
| ID inválido (validación en el cliente) | ✗ ID inválido: debe ser un número entero mayor que cero. |
| Datos incorrectos (400) | ✗ Datos incorrectos: … |
| Error del servidor (5xx) | ✗ Error del servidor (500)… |
| Error de conexión | ✗ Error de conexión: no se pudo comunicar con la API… |

## Comparación final (B19)

| Característica | XMLHttpRequest | fetch + async/await |
|---|---|---|
| Crear objeto | `const xhr = new XMLHttpRequest()` | No hay objeto que crear: se llama a la función `fetch()` |
| Configurar solicitud | `xhr.open(método, url)`, `xhr.setRequestHeader(...)`, `xhr.timeout` | Un objeto de opciones: `fetch(url, { method, headers, body })` |
| Enviar solicitud | `xhr.send(cuerpo)` como paso aparte | Se envía al llamar a `fetch()`; se espera con `await` |
| Obtener respuesta | `xhr.responseText` y `xhr.status` dentro de un callback | El objeto `Response` (`response.status`, `response.ok`) |
| Obtener JSON | `JSON.parse(xhr.responseText)` a mano | `await response.json()` |
| Manejo de errores | `readyState`, `status` (0 = sin conexión), `onerror` / `ontimeout` | `try/catch` para fallos de red y `response.ok` para 4xx/5xx |
| Código asíncrono | Callbacks (`onreadystatechange`); anidar pasos genera "callback hell" | Promesas con `async/await`; el código se lee en orden |
| Lectura del código | Más largo y repartido en funciones de retorno | Más corto y secuencial |

### Errores con fetch (B7)

`fetch()` **solo rechaza la promesa ante errores de red** (sin conexión, DNS, CORS). Si el servidor responde 400, 404 o 500, la promesa **se cumple** y hay que revisar `response.ok` (o `response.status`) para detectarlo. Por eso `api.js` usa `try/catch` para el error de conexión y `if (!response.ok)` para los códigos HTTP. En XMLHttpRequest, en cambio, un error de conexión se reconoce porque `xhr.status` vale `0`.

## Cómo ejecutarlo

Abrir `xhr/index.html` o `fetch/index.html` en el navegador (o con Live Server). La API está en Render y puede tardar hasta un minuto en responder la primera vez.

## Evidencias

Agregar capturas de ambas versiones: consulta general, búsqueda por ID, alta con ID manual y automático, modificación, eliminación y al menos un error.
