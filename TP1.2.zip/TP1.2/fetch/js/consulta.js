function irAModificar(id) { location.href = "alta.html?id=" + encodeURIComponent(id); }

function mostrarEnTabla(autos) { mostrarAutos($("lista"), autos, irAModificar, borrar); }

async function cargarTodos() {
  $("estado").textContent = "Cargando automóviles… (la primera vez puede tardar hasta un minuto)";
  try {
    const autos = await obtenerAutos();
    console.log(autos);
    mostrarEnTabla(autos);
    $("estado").textContent = autos.length + " automóviles.";
  } catch (error) {
    $("estado").textContent = "No se pudo cargar la lista.";
    mostrarError(error.message);
  }
}

async function borrar(id) {
  if (!confirm("¿Seguro que querés eliminar el automóvil " + id + "?")) return;
  try {
    await eliminarAuto(id);
    mostrarMensaje("✓ Automóvil eliminado correctamente.", "ok");
    await cargarTodos(); // la tabla refleja la eliminación
  } catch (error) {
    mostrarError(error.message);
  }
}

$("form-buscar").addEventListener("submit", async function (ev) {
  ev.preventDefault();
  const id = idValido($("id-buscar").value);
  if (id === null) return mostrarError(MSG_ID_INVALIDO);
  limpiarMensaje();
  try {
    const auto = await obtenerAuto(id);
    mostrarEnTabla([auto]); // reemplaza la tabla anterior
    $("estado").textContent = "Resultado de la búsqueda por ID.";
    mostrarMensaje("✓ Automóvil encontrado.", "ok");
  } catch (error) {
    mostrarEnTabla([]);
    $("estado").textContent = "Sin resultados.";
    mostrarError(error.message);
  }
});

$("btn-todos").addEventListener("click", function () { limpiarMensaje(); cargarTodos(); });

cargarTodos();
