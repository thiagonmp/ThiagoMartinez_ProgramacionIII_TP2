// Utilidades de interfaz y validación. Este archivo es IDÉNTICO en las dos versiones.
const $ = (id) => document.getElementById(id);

const MSG_CONEXION = "✗ Error de conexión: no se pudo comunicar con la API. Revisá tu conexión o esperá un minuto si la API estaba inactiva.";
const MSG_NO_EXISTE = "✗ No existe un automóvil con ese ID.";
const MSG_ID_INVALIDO = "✗ ID inválido: debe ser un número entero mayor que cero.";

// Muestra el mensaje en la página y en la consola (y opcionalmente con alert).
function mostrarMensaje(texto, tipo, conAlert) {
  console.log(texto);
  const m = $("mensaje");
  m.textContent = texto;
  m.className = tipo || "";
  if (conAlert) alert(texto);
}
function mostrarError(texto, conAlert) { mostrarMensaje(texto, "error", conAlert); }
function limpiarMensaje() { const m = $("mensaje"); m.textContent = ""; m.className = ""; }

// Traduce un código HTTP a un mensaje para el usuario.
function mensajeHttp(status, datos) {
  let detalle = (datos && (datos.error || datos.mensaje || datos.message)) || "";
  if (typeof detalle !== "string") detalle = JSON.stringify(detalle);
  if (status === 404) return MSG_NO_EXISTE;
  if (status === 409 || /ya existe|duplic/i.test(detalle)) return "✗ Ya existe un automóvil con ese ID.";
  if (status === 400) return "✗ Datos incorrectos" + (detalle ? ": " + detalle : ".");
  if (status >= 500) return `✗ Error del servidor (${status}). Intentá nuevamente más tarde.`;
  return `✗ Error inesperado (HTTP ${status}).`;
}

// La API puede devolver un arreglo o un objeto contenedor: se normaliza.
const listaDeAutos = (d) => (Array.isArray(d) ? d : (d && d.autos) || []);
function autoDe(d) {
  const a = Array.isArray(d) ? d[0] : d && (d.auto || d);
  return a && a.id !== undefined ? a : null;
}

// Devuelve un entero > 0 o null.
function idValido(texto) {
  const t = String(texto).trim();
  const n = Number(t);
  return t !== "" && Number.isInteger(n) && n > 0 ? n : null;
}

function validarAuto({ marca, precio, color }) {
  if (!marca) return "✗ La marca es obligatoria.";
  if (!Number.isFinite(precio) || precio <= 0) return "✗ El precio es obligatorio y debe ser mayor que cero.";
  if (!/^#[0-9a-fA-F]{6}$/.test(color || "")) return "✗ El color es obligatorio y debe ser hexadecimal, por ejemplo #430839.";
  return null;
}

// Construye la tabla dinámicamente con createElement (sin filas escritas en el HTML).
function mostrarAutos(tbody, autos, alModificar, alEliminar) {
  tbody.replaceChildren();
  if (autos.length === 0) {
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 5;
    td.className = "vacio";
    td.textContent = "No hay automóviles para mostrar.";
    tr.append(td);
    tbody.append(tr);
    return;
  }
  for (const a of autos) {
    const tr = document.createElement("tr");
    for (const v of [a.id, a.marca, Number(a.precio).toLocaleString("es-AR")]) {
      const td = document.createElement("td");
      td.textContent = v;
      tr.append(td);
    }

    const tdColor = document.createElement("td");
    const wrap = document.createElement("div");
    wrap.className = "color-celda";
    const muestra = document.createElement("span");
    muestra.className = "muestra";
    muestra.style.background = a.color;
    wrap.append(muestra, document.createTextNode(a.color));
    tdColor.append(wrap);

    const tdAcc = document.createElement("td");
    const acciones = document.createElement("div");
    acciones.className = "acciones";
    const bMod = document.createElement("button");
    bMod.type = "button";
    bMod.className = "secundario";
    bMod.textContent = "Modificar";
    bMod.addEventListener("click", () => alModificar(a.id));
    const bDel = document.createElement("button");
    bDel.type = "button";
    bDel.className = "peligro";
    bDel.textContent = "Eliminar";
    bDel.addEventListener("click", () => alEliminar(a.id));
    acciones.append(bMod, bDel);
    tdAcc.append(acciones);

    tr.append(tdColor, tdAcc);
    tbody.append(tr);
  }
}
