// Acceso a la API usando EXCLUSIVAMENTE fetch() con async/await.
const API = "https://api-autos-tgwd.onrender.com/autos";

async function solicitar(metodo, ruta, cuerpo) {
  let response;
  try {
    response = await fetch(API + ruta, {
      method: metodo,
      headers: cuerpo !== undefined ? { "Content-Type": "application/json" } : undefined,
      body: cuerpo !== undefined ? JSON.stringify(cuerpo) : undefined,
    });
  } catch (error) {
    // fetch solo rechaza la promesa ante fallos de red: un 404 o 500 NO llega acá.
    throw new Error(MSG_CONEXION);
  }

  let datos = null;
  try { datos = await response.json(); } catch (error) { /* respuesta sin JSON */ }

  if (!response.ok) throw new Error(mensajeHttp(response.status, datos)); // 400, 404, 500...
  return datos;
}

async function obtenerAutos() { return listaDeAutos(await solicitar("GET", "")); }
async function obtenerAuto(id) {
  const auto = autoDe(await solicitar("GET", "/" + id));
  if (!auto) throw new Error(MSG_NO_EXISTE);
  return auto;
}
const agregarAuto = (auto) => solicitar("POST", "", auto);
const modificarAuto = (id, auto) => solicitar("PUT", "/" + id, auto);
const eliminarAuto = (id) => solicitar("DELETE", "/" + id);
