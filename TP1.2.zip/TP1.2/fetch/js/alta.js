// Esta página sirve para agregar y para modificar: si la URL trae ?id=N, es una modificación.
const errorAlta = (texto) => mostrarError(texto, true);
let idEdicion = null;

async function prepararEdicion(idTexto) {
  const id = idValido(idTexto);
  if (id === null) return errorAlta(MSG_ID_INVALIDO);
  try {
    const auto = await obtenerAuto(id);
    idEdicion = auto.id;
    $("id").value = auto.id;
    $("id").disabled = true; // el ID no se modifica
    $("marca").value = auto.marca;
    $("precio").value = auto.precio;
    $("color").value = auto.color;
    $("titulo-form").textContent = "Modificar automóvil " + auto.id;
    $("btn-guardar").textContent = "Guardar cambios";
    $("nota-id").hidden = true;
  } catch (error) {
    errorAlta(error.message);
  }
}

const idParam = new URLSearchParams(location.search).get("id");
if (idParam !== null) prepararEdicion(idParam);

$("form-alta").addEventListener("submit", async function (ev) {
  ev.preventDefault();
  const editando = idEdicion !== null;
  const datos = { marca: $("marca").value.trim(), precio: Number($("precio").value), color: $("color").value };

  if (!editando && $("id").value.trim() !== "") { // el ID es opcional
    const id = idValido($("id").value);
    if (id === null) return errorAlta(MSG_ID_INVALIDO);
    datos.id = id;
  }
  const error = validarAuto(datos);
  if (error) return errorAlta(error);

  const btn = $("btn-guardar");
  btn.disabled = true;
  try {
    if (editando) {
      await modificarAuto(idEdicion, datos);
      mostrarMensaje("✓ Automóvil modificado correctamente.", "ok", true);
      location.href = "consulta.html";
    } else {
      const creado = await agregarAuto(datos);
      const nuevo = creado && (creado.id !== undefined ? creado.id : creado.auto && creado.auto.id);
      mostrarMensaje("✓ Automóvil agregado correctamente." + (nuevo !== undefined ? " ID asignado: " + nuevo + "." : ""), "ok", true);
      $("form-alta").reset(); // solo se limpia si la operación fue exitosa
    }
  } catch (e) {
    errorAlta(e.message);
  } finally {
    btn.disabled = false;
  }
});
